
const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const nodemailer = require("nodemailer");

const app = express();
app.use(cors());
app.use(bodyParser.json());

app.post("/send-email", async (req, res) => {
  const { txId } = req.body;
  if (!txId) return res.status(400).send("TXID required");

  try {
    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: "your-email@gmail.com",
        pass: "your-app-password"
      }
    });

    await transporter.sendMail({
      from: 'your-email@gmail.com',
      to: 'your-email@gmail.com',
      subject: 'TXID جدید ثبت شد',
      text: `کاربر یک TXID ثبت کرده: ${txId}`,
    });

    res.send("ایمیل ارسال شد");
  } catch (err) {
    res.status(500).send("خطا در ارسال ایمیل");
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log("Server running on port " + PORT));
