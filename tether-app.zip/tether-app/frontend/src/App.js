
import React, { useState } from "react";
import QRCode from "react-qr-code";

const USDT_ADDRESS = "TXsdtxxgDXWtYDNgkqtCPVPb2a9CTHsDkF";

function App() {
  const [showQR, setShowQR] = useState(false);
  const [txId, setTxId] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSendTxId = async () => {
    if (!txId) return alert("لطفاً TXID را وارد کنید.");
    setIsSending(true);
    try {
      const response = await fetch("http://localhost:5000/send-email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ txId }),
      });
      if (response.ok) {
        setSent(true);
        alert("TXID با موفقیت ارسال شد.");
      } else {
        alert("ارسال ناموفق بود.");
      }
    } catch (err) {
      alert("خطا در ارتباط با سرور.");
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div style={{ padding: 20, fontFamily: "sans-serif", background: "#fff8e1", minHeight: "100vh" }}>
      <h2 style={{ color: "#cfa000" }}>💰 باشگاه طلایی | اشتراک ربات طلا</h2>
      <p>برای فعال‌سازی اشتراک ماهانه، لطفاً مبلغ <strong>10 USDT</strong> را پرداخت کنید.</p>
      {showQR ? (
        <div style={{ marginTop: 20 }}>
          <QRCode value={USDT_ADDRESS} size={128} />
          <p style={{ fontSize: 12, wordBreak: "break-all" }}>{USDT_ADDRESS}</p>
          <input
            placeholder="TXID تراکنش را وارد کنید"
            value={txId}
            onChange={(e) => setTxId(e.target.value)}
            style={{ padding: 8, width: "100%", marginTop: 10 }}
          />
          <button
            onClick={handleSendTxId}
            disabled={isSending || sent}
            style={{
              marginTop: 10,
              padding: 10,
              width: "100%",
              background: "#cfa000",
              color: "#fff",
              border: "none",
              cursor: "pointer"
            }}
          >
            {sent ? "✓ ارسال شد" : isSending ? "در حال ارسال..." : "ارسال TXID"}
          </button>
        </div>
      ) : (
        <button
          onClick={() => setShowQR(true)}
          style={{
            marginTop: 20,
            padding: 10,
            width: "100%",
            background: "#cfa000",
            color: "#fff",
            border: "none",
            cursor: "pointer"
          }}
        >
          پرداخت با تتر
        </button>
      )}
    </div>
  );
}

export default App;
